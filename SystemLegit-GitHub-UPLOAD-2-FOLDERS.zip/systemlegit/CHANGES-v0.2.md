# SystemLegit HUD v0.2 changes

Independent, source-only Fabric Java 1.21.1 update.

- Multi-widget layout engine: normalized positions, saved JSON.
- Drag-and-drop HUD Editor: H key, ClickGUI shortcut, theme / reset / snapping.
- Four accent themes: Aqua, Violet, Rose, Amber.
- New Target HUD with actual skin face, smoothed health, absorption and distance.
- Expanded arraylist, watermark, coordinates, potions, status, keys and waypoint visuals.
- New panels: Keybinds, Armor, Session, CPS, Notifications.
- Toggle notifications with 3.8 s duration.
- Kept the original combat module mechanics and game-version configuration intact.

No full Fabric compilation or game runtime test in this environment.
