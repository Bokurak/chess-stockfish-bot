﻿$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$project = $PSScriptRoot
Set-Location -LiteralPath $project

Write-Host ''
Write-Host '===== SystemLegit 1.21.1 - JAR Builder =====' -ForegroundColor Cyan
Write-Host 'Minecraft: 1.21.1  |  Java: 21  |  Fabric Loom: 1.11.8'

if (-not (Get-Command java -ErrorAction SilentlyContinue) -or -not (Get-Command javac -ErrorAction SilentlyContinue)) {
    throw 'JDK 21 not found. Install it: https://adoptium.net/temurin/releases/?version=21'
}
$versionText = (& cmd.exe /d /c "java -version 2>&1" | Out-String)
if ($versionText -notmatch 'version "21\.' -and $versionText -notmatch 'openjdk 21\.') {
    Write-Host $versionText
    throw 'Wrong Java version. Select JDK 21 (JAVA_HOME and PATH).'
}

$gradleVersion = '8.14.3'
$tools = Join-Path $project '.build-tools'
$gradleExe = Join-Path $tools "gradle-$gradleVersion\bin\gradle.bat"
if (-not (Test-Path -LiteralPath $gradleExe)) {
    New-Item -ItemType Directory -Force -Path $tools | Out-Null
    $gradleZip = Join-Path $tools "gradle-$gradleVersion-bin.zip"
    # PowerShell 5.1 requires TLS 1.2 to connect to some HTTPS endpoints.
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    if (-not (Test-Path -LiteralPath $gradleZip)) {
        $urls = @(
            "https://downloads.gradle.org/distributions/gradle-$gradleVersion-bin.zip",
            "https://services.gradle.org/distributions/gradle-$gradleVersion-bin.zip"
        )
        $downloaded = $false
        foreach ($url in $urls) {
            Write-Host "Trying $url" -ForegroundColor Yellow
            try {
                Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $gradleZip -TimeoutSec 300 -ErrorAction Stop
                if ((Get-Item -LiteralPath $gradleZip).Length -lt 100MB) {
                    throw 'Download looks incomplete (file smaller than 100 MB).'
                }
                $downloaded = $true
                break
            } catch {
                Write-Warning "Download failed: $($_.Exception.Message)"
                if (Test-Path -LiteralPath $gradleZip) { Remove-Item -LiteralPath $gradleZip -Force }
            }
        }
        if (-not $downloaded) {
            Write-Host ''
            Write-Host 'Automatic download failed. Manual workaround:' -ForegroundColor Yellow
            Write-Host '1. Open in a browser: https://downloads.gradle.org/distributions/gradle-8.14.3-bin.zip'
            Write-Host "2. Save the ZIP WITHOUT EXTRACTING as: $gradleZip"
            Write-Host '3. Run BUILD_JAR.bat again.'
            throw 'Cannot download Gradle. The ZIP can be supplied manually.'
        }
    } else {
        Write-Host "Using locally downloaded Gradle ZIP: $gradleZip" -ForegroundColor Green
    }
    # Inspect ZIP before extraction; do not report success for an incomplete download.
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction Stop
        $z = [System.IO.Compression.ZipFile]::OpenRead($gradleZip)
        try {
            $entry = $z.GetEntry("gradle-$gradleVersion/bin/gradle.bat")
            if ($null -eq $entry) { throw 'ZIP does not contain Gradle bin/gradle.bat.' }
        } finally {
            $z.Dispose()
        }
    } catch {
        Write-Host "Invalid Gradle ZIP: $($_.Exception.Message)" -ForegroundColor Red
        if (Test-Path -LiteralPath $gradleZip) { Remove-Item -LiteralPath $gradleZip -Force }
        throw 'Download Gradle ZIP again from the official site.'
    }
    Write-Host 'Extracting Gradle...'
    Expand-Archive -LiteralPath $gradleZip -DestinationPath $tools -Force
    Write-Host 'Gradle extracted.'
}
if (-not (Test-Path -LiteralPath $gradleExe)) { throw 'Gradle installation incomplete.' }

Write-Host 'Building Fabric mod and downloading build dependencies...' -ForegroundColor Cyan
& $gradleExe clean build --no-daemon --console=plain
if ($LASTEXITCODE -ne 0) { throw "Gradle build failed with exit code $LASTEXITCODE. See errors above." }

$libs = Join-Path $project 'build\libs'
$modJar = Get-ChildItem -LiteralPath $libs -Filter '*.jar' | Where-Object { $_.Name -notmatch '-(sources|dev|javadoc)\.jar$' } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $modJar) { throw 'Build completed but no installable JAR found in build/libs.' }
$destination = Join-Path $project 'SystemLegit-1.21.1.jar'
Copy-Item -LiteralPath $modJar.FullName -Destination $destination -Force
Write-Host ''
Write-Host "SUCCESS: $destination" -ForegroundColor Green
Write-Host 'You must also install Fabric Loader 1.21.1 and Fabric API 1.21.1.'
Write-Host 'The Minecraft mods folder is: %APPDATA%\.minecraft\mods'
$choice = Read-Host 'Copy mod to default Minecraft mods folder now? [Y/N]'
if ($choice -match '^(Y|y|Yes|yes|Д|д)$') {
    if (-not $env:APPDATA) { throw 'APPDATA environment variable is missing.' }
    $mods = Join-Path $env:APPDATA '.minecraft\mods'
    New-Item -ItemType Directory -Force -Path $mods | Out-Null
    Copy-Item -LiteralPath $destination -Destination (Join-Path $mods (Split-Path $destination -Leaf)) -Force
    Write-Host "Copied to: $mods" -ForegroundColor Green
    Write-Host 'Note: Fabric API must be installed separately.'
}
