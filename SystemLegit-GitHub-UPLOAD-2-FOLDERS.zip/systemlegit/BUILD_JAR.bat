@echo off
setlocal
cd /d "%~dp0"
echo SystemLegit - Minecraft 1.21.1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-one-click.ps1"
set "BUILD_RESULT=%ERRORLEVEL%"
if not "%BUILD_RESULT%"=="0" echo Build unsuccessful. See the first error above.
echo.
pause
exit /b %BUILD_RESULT%
