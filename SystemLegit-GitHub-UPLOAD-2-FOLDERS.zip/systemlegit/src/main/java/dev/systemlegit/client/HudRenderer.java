package dev.systemlegit.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Deque;
import java.util.List;
import java.util.Locale;

/** 2D interface: standalone draggable panels, animated health and live game data. */
public final class HudRenderer {
    public static final int ACCENT = 0xFF74DBD3;
    public static final int WHITE = 0xFFF2F4FA;
    public static final int MUTED = 0xFF9EA9C2;
    private static final int PANEL = 0xE9151B2C;
    private static final int DIVIDER = 0xFF333A4E;
    private static final long START_TIME = System.currentTimeMillis();
    private static final Deque<Notice> NOTICES = new ArrayDeque<>();
    private static float easedHealth = -1.0f;
    private static java.util.UUID previousTarget;
    private record Notice(String title, String detail, long createdAt) {}

    private HudRenderer() {}
    public static void notify(String title, String detail) {
        NOTICES.addLast(new Notice(title, detail, System.currentTimeMillis()));
        while (NOTICES.size() > 4) NOTICES.removeFirst();
    }
    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden || mc.currentScreen instanceof LegitScreen
                || mc.currentScreen instanceof HudEditorScreen) return;
        drawAll(ctx, false);
    }
    public static void renderEditor(DrawContext ctx) { drawAll(ctx, true); }

    private static void drawAll(DrawContext ctx, boolean preview) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        for (HudLayout.Widget widget : HudLayout.Widget.values()) {
            if (!SystemLegitClient.on(widget.moduleId)) continue;
            if (!preview && widget == HudLayout.Widget.TARGET && !validTarget()) continue;
            if (!preview && widget == HudLayout.Widget.WAYPOINT && SystemLegitClient.waypoint == null) continue;
            if (!preview && widget == HudLayout.Widget.NOTIFICATIONS && NOTICES.isEmpty()) continue;
            int[] r = bounds(widget, mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight(), preview);
            drawWidget(ctx, mc, widget, r[0], r[1], r[2], r[3], preview);
        }
    }
    public static int[] bounds(HudLayout.Widget widget, int sw, int sh, boolean preview) {
        int[] size = measure(widget, preview);
        return HudLayout.rectangle(widget, sw, sh, size[0], size[1]);
    }
    public static int[] measure(HudLayout.Widget widget, boolean preview) {
        MinecraftClient mc = MinecraftClient.getInstance();
        return switch (widget) {
            case WATERMARK -> new int[]{158, 39};
            case ARRAYLIST -> {
                int rows = moduleNames().size();
                int max = 110;
                for (String name : moduleNames()) max = Math.max(max, mc.textRenderer.getWidth(name) + 27);
                yield new int[]{Math.min(187, max), 25 + Math.max(1, rows) * 17};
            }
            case COORDINATES -> new int[]{194, 49};
            case KEYSTROKES -> new int[]{91, 94};
            case TARGET -> new int[]{198, 78};
            case POTIONS -> new int[]{168, 28 + Math.max(1, Math.min(5, mc.player == null ? 0 : mc.player.getStatusEffects().size())) * 16};
            case STATUS -> new int[]{194, 66};
            case WAYPOINT -> new int[]{185, 44};
            case BINDS -> new int[]{158, 96};
            case ARMOR -> new int[]{122, 41};
            case SESSION -> new int[]{166, 67};
            case CPS -> new int[]{116, 44};
            case NOTIFICATIONS -> new int[]{191, 16 + Math.max(1, NOTICES.size()) * 40};
        };
    }
    private static boolean validTarget() {
        return SystemLegitClient.recentTarget instanceof PlayerEntity t && t.isAlive()
                && SystemLegitClient.recentTargetTicks > 0;
    }
    private static List<String> moduleNames() {
        List<String> out = new ArrayList<>();
        for (Module m : SystemLegitClient.MODULES) {
            if (m.enabled && (m.category == Module.Category.COMBAT || m.category == Module.Category.MOVEMENT
                    || m.category == Module.Category.RENDER) && !m.id.equals("arraylist")) out.add(m.name);
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        out.sort(Comparator.comparingInt((String s) -> mc.textRenderer.getWidth(s)).reversed());
        return out;
    }
    private static int tint() { return HudLayout.theme.accent; }
    private static void box(DrawContext c, int x, int y, int w, int h) {
        // Rounded-corner silhouette using vanilla DrawContext only (no custom shader dependency).
        c.fill(x + 4, y, x + w - 4, y + h, PANEL);
        c.fill(x + 1, y + 3, x + w - 1, y + h - 3, PANEL);
        c.fill(x + 2, y + 1, x + w - 2, y + h - 1, PANEL);
        c.fill(x + 1, y + 5, x + 2, y + h - 5, 0xAA343D55);
        c.fill(x + w - 2, y + 5, x + w - 1, y + h - 5, 0xAA343D55);
        c.fill(x + 4, y, x + Math.min(w - 4, 32), y + 2, tint());
    }
    private static void t(DrawContext ctx, MinecraftClient mc, String label, int x, int y, int color) {
        ctx.drawTextWithShadow(mc.textRenderer, label, x, y, color);
    }
    private static void header(DrawContext c, MinecraftClient mc, String s, int x, int y, int w) {
        t(c, mc, s, x + 9, y + 8, tint());
        c.fill(x + 9, y + 22, x + w - 9, y + 23, DIVIDER);
    }
    private static String shortText(MinecraftClient mc, String source, int width) {
        return mc.textRenderer.trimToWidth(source, Math.max(5, width));
    }
    private static String time(int ticks) {
        if (ticks > 20 * 60 * 59) return "LONG";
        int seconds = Math.max(0, ticks / 20);
        return (seconds / 60) + ":" + String.format(Locale.ROOT, "%02d", seconds % 60);
    }
    private static String duration(long seconds) {
        return String.format(Locale.ROOT, "%02d:%02d:%02d", seconds / 3600, (seconds / 60) % 60, seconds % 60);
    }
    private static int ping(MinecraftClient mc) {
        if (mc.player == null || mc.getNetworkHandler() == null) return -1;
        var entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return entry == null ? -1 : entry.getLatency();
    }
    private static void line(DrawContext c, int x, int y, int width, float fraction, int color) {
        c.fill(x, y, x + width, y + 5, DIVIDER);
        c.fill(x, y, x + (int)(MathHelper.clamp(fraction, 0f, 1f) * width), y + 5, color);
    }
    private static int lerpColor(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = (int)(ar + (br - ar) * t), g = (int)(ag + (bg - ag) * t), blue = (int)(ab + (bb - ab) * t);
        return 0xFF000000 | r << 16 | g << 8 | blue;
    }

    private static void drawWidget(DrawContext ctx, MinecraftClient mc, HudLayout.Widget widget,
                                   int x, int y, int w, int h, boolean preview) {
        box(ctx, x, y, w, h);
        switch (widget) {
            case WATERMARK -> {
                t(ctx, mc, "S", x + 11, y + 10, tint());
                t(ctx, mc, "SYSTEM LEGIT", x + 24, y + 8, WHITE);
                t(ctx, mc, "1.21.1   /   " + mc.getCurrentFps() + " FPS", x + 24, y + 22, MUTED);
                ctx.fill(x + 24, y + 35, x + w - 9, y + 36, 0xFF354357);
            }
            case ARRAYLIST -> {
                t(ctx, mc, "ACTIVE MODULES", x + 10, y + 8, tint());
                List<String> names = moduleNames();
                if (names.isEmpty()) names = List.of("No modules");
                for (int i = 0; i < names.size(); i++) {
                    int yy = y + 26 + i * 17;
                    if (yy + 10 > y + h) break;
                    ctx.fill(x + w - 5, yy, x + w - 3, yy + 12, lerpColor(tint(), 0xFF7B90AC, Math.min(.80f, i * .13f)));
                    t(ctx, mc, shortText(mc, names.get(i), w - 20), x + 10, yy + 2, WHITE);
                }
            }
            case COORDINATES -> {
                header(ctx, mc, "COORDINATES", x, y, w);
                var p = mc.player.getBlockPos();
                t(ctx, mc, String.format(Locale.ROOT, "X %d   Y %d   Z %d", p.getX(), p.getY(), p.getZ()), x + 10, y + 29, WHITE);
                t(ctx, mc, shortText(mc, mc.world.getRegistryKey().getValue().toString(), w - 20), x + 10, y + 40, MUTED);
            }
            case KEYSTROKES -> {
                key(ctx, mc, x + 34, y + 6, "W", mc.options.forwardKey.isPressed(), 23, 23);
                key(ctx, mc, x + 8, y + 31, "A", mc.options.leftKey.isPressed(), 23, 23);
                key(ctx, mc, x + 34, y + 31, "S", mc.options.backKey.isPressed(), 23, 23);
                key(ctx, mc, x + 60, y + 31, "D", mc.options.rightKey.isPressed(), 23, 23);
                key(ctx, mc, x + 8, y + 56, "LMB", mc.options.attackKey.isPressed(), 35, 16);
                key(ctx, mc, x + 48, y + 56, "RMB", mc.options.useKey.isPressed(), 35, 16);
                t(ctx, mc, "MOVEMENT", x + 18, y + 81, MUTED);
            }
            case TARGET -> drawTarget(ctx, mc, x, y, w, h, preview);
            case POTIONS -> {
                header(ctx, mc, "POTION EFFECTS", x, y, w);
                List<StatusEffectInstance> list = new ArrayList<>(mc.player.getStatusEffects());
                list.sort(Comparator.comparingInt(StatusEffectInstance::getDuration).reversed());
                if (list.isEmpty()) t(ctx, mc, "No active effects", x + 10, y + 31, MUTED);
                for (int i = 0; i < Math.min(5, list.size()); i++) {
                    StatusEffectInstance effect = list.get(i);
                    String name = effect.getEffectType().value().getName().getString();
                    String suffix = " " + (effect.getAmplifier() + 1);
                    int yy = y + 29 + i * 16;
                    ctx.fill(x + 10, yy + 2, x + 13, yy + 11, tint());
                    t(ctx, mc, shortText(mc, name + suffix, w - 62), x + 19, yy + 3, WHITE);
                    t(ctx, mc, time(effect.getDuration()), x + w - 43, yy + 3, MUTED);
                }
            }
            case STATUS -> {
                header(ctx, mc, "PLAYER STATUS", x, y, w);
                float hp = mc.player.getHealth();
                float max = Math.max(1, mc.player.getMaxHealth());
                String hpLabel = String.format(Locale.ROOT, "HP %.1f/%.1f", hp, max);
                t(ctx, mc, hpLabel, x + 9, y + 29, WHITE);
                t(ctx, mc, "PING " + (ping(mc) < 0 ? "--" : ping(mc) + "ms"), x + 125, y + 29, MUTED);
                line(ctx, x + 9, y + 43, w - 18, hp / max, tint());
                t(ctx, mc, "FOOD " + mc.player.getHungerManager().getFoodLevel() + "/20", x + 9, y + 53, MUTED);
                t(ctx, mc, "ARMOR " + mc.player.getArmor(), x + 119, y + 53, MUTED);
            }
            case WAYPOINT -> {
                header(ctx, mc, "WAYPOINT  [N]", x, y, w);
                if (SystemLegitClient.waypoint == null) {
                    t(ctx, mc, "Press N to set a point", x + 10, y + 29, MUTED);
                } else {
                    var p = SystemLegitClient.waypoint;
                    boolean same = mc.world.getRegistryKey().getValue().toString().equals(p.dimension());
                    int distance = (int) Math.round(Math.hypot(p.x() - mc.player.getX(), p.z() - mc.player.getZ()));
                    String line = same ? p.x() + " " + p.y() + " " + p.z() + "  / " + distance + "m" : "Different dimension";
                    t(ctx, mc, shortText(mc, line, w - 20), x + 10, y + 30, WHITE);
                }
            }
            case BINDS -> {
                header(ctx, mc, "KEYBINDS", x, y, w);
                t(ctx, mc, "ClickGUI", x + 9, y + 30, WHITE);
                t(ctx, mc, "RSHIFT", x + w - 47, y + 30, tint());
                t(ctx, mc, "HUD editor", x + 9, y + 44, WHITE);
                t(ctx, mc, "H", x + w - 18, y + 44, tint());
                t(ctx, mc, "Zoom", x + 9, y + 58, SystemLegitClient.on("zoom") ? WHITE : MUTED);
                t(ctx, mc, "Z", x + w - 18, y + 58, tint());
                t(ctx, mc, "Waypoint", x + 9, y + 72, WHITE);
                t(ctx, mc, "N", x + w - 18, y + 72, tint());
            }
            case ARMOR -> {
                t(ctx, mc, "ARMOR", x + 9, y + 6, tint());
                for (int i = 0; i < 4; i++) {
                    ItemStack stack = mc.player.getInventory().armor.get(3 - i);
                    if (!stack.isEmpty()) ctx.drawItem(stack, x + 13 + i * 28, y + 20);
                    else ctx.fill(x + 13 + i * 28, y + 20, x + 29 + i * 28, y + 36, DIVIDER);
                }
            }
            case SESSION -> {
                header(ctx, mc, "SESSION INFO", x, y, w);
                long seconds = (System.currentTimeMillis() - START_TIME) / 1000;
                t(ctx, mc, "PLAYTIME", x + 9, y + 29, MUTED);
                t(ctx, mc, duration(seconds), x + 79, y + 29, WHITE);
                t(ctx, mc, "FPS", x + 9, y + 44, MUTED);
                t(ctx, mc, "" + mc.getCurrentFps(), x + 79, y + 44, WHITE);
                t(ctx, mc, "PING", x + 9, y + 57, MUTED);
                t(ctx, mc, ping(mc) < 0 ? "--" : ping(mc) + "ms", x + 79, y + 57, WHITE);
            }
            case CPS -> {
                t(ctx, mc, "CLICKS / SEC", x + 9, y + 7, tint());
                t(ctx, mc, SystemLegitClient.currentCps + " CPS", x + 9, y + 24, WHITE);
                t(ctx, mc, "sampled at 20 Hz", x + 58, y + 26, MUTED);
            }
            case NOTIFICATIONS -> {
                List<Notice> notices = new ArrayList<>(NOTICES);
                if (notices.isEmpty() && preview) notices.add(new Notice("HUD READY", "Drag to position", System.currentTimeMillis()));
                long now = System.currentTimeMillis();
                int i = 0;
                for (Notice notice : notices) {
                    if (!preview && now - notice.createdAt > 3800) continue;
                    int yy = y + 6 + i * 40;
                    ctx.fill(x + 9, yy, x + 12, yy + 28, tint());
                    t(ctx, mc, shortText(mc, notice.title, w - 28), x + 19, yy + 2, WHITE);
                    t(ctx, mc, shortText(mc, notice.detail, w - 28), x + 19, yy + 16, MUTED);
                    i++;
                }
            }
        }
    }
    private static void key(DrawContext ctx, MinecraftClient mc, int x, int y, String label,
                            boolean active, int w, int h) {
        ctx.fill(x, y, x + w, y + h, active ? 0xFF307B78 : 0xFF293246);
        ctx.drawCenteredTextWithShadow(mc.textRenderer, label, x + w / 2, y + (h - 8) / 2, active ? WHITE : MUTED);
    }
    private static void drawTarget(DrawContext ctx, MinecraftClient mc, int x, int y, int w, int h, boolean preview) {
        PlayerEntity target = validTarget() ? (PlayerEntity) SystemLegitClient.recentTarget : (preview ? mc.player : null);
        if (target == null) return;
        java.util.UUID uuid = target.getUuid();
        float health = target.getHealth(), max = Math.max(1, target.getMaxHealth());
        if (!uuid.equals(previousTarget) || easedHealth < 0) easedHealth = health;
        previousTarget = uuid;
        easedHealth += (health - easedHealth) * .20f;
        String name = shortText(mc, target.getName().getString(), w - 86);
        // Draw the actual current player's / target player's skin from the network profile when available.
        if (mc.getNetworkHandler() != null) {
            var info = mc.getNetworkHandler().getPlayerListEntry(uuid);
            if (info != null) {
                Identifier skin = info.getSkinTextures().texture();
                ctx.drawTexture(skin, x + 10, y + 12, 32, 32, 8, 8, 8, 8, 64, 64);
                ctx.drawTexture(skin, x + 10, y + 12, 32, 32, 40, 8, 8, 8, 64, 64);
            }
        }
        t(ctx, mc, name, x + 51, y + 12, WHITE);
        t(ctx, mc, "TARGET", x + 51, y + 26, tint());
        double distance = mc.player.distanceTo(target);
        t(ctx, mc, String.format(Locale.ROOT, "%.1fm", distance), x + w - 44, y + 27, MUTED);
        t(ctx, mc, String.format(Locale.ROOT, "%.1f / %.1f HP", health, max), x + 10, y + 49, WHITE);
        float absorption = target.getAbsorptionAmount();
        if (absorption > 0) t(ctx, mc, String.format(Locale.ROOT, "+%.0f", absorption), x + w - 39, y + 49, 0xFFFFC67A);
        line(ctx, x + 10, y + 64, w - 20, easedHealth / max, tint());
        ctx.fill(x + 10, y + 73, x + w - 10, y + 74, DIVIDER);
    }
    public static void sweepNotices() {
        long now = System.currentTimeMillis();
        while (!NOTICES.isEmpty() && now - NOTICES.peekFirst().createdAt > 3800) NOTICES.removeFirst();
    }
}
