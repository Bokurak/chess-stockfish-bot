package dev.systemlegit.client;

import java.util.EnumMap;
import java.util.Map;

/** Layout is stored as fractions of the free screen space, so widgets stay on-screen at different resolutions. */
public final class HudLayout {
    public enum Theme {
        AQUA("Aqua", 0xFF74DBD3), VIOLET("Violet", 0xFFAD94FF),
        ROSE("Rose", 0xFFFF93B6), AMBER("Amber", 0xFFFFC67A);
        public final String label;
        public final int accent;
        Theme(String label, int accent) { this.label = label; this.accent = accent; }
    }
    public enum Widget {
        WATERMARK("watermark", "Watermark", .014, .022),
        ARRAYLIST("arraylist", "Module list", .986, .022),
        COORDINATES("coordinates", "Coordinates", .014, .975),
        KEYSTROKES("keystrokes", "Keystrokes", .49, .80),
        TARGET("target_hud", "Target HUD", .56, .56),
        POTIONS("potions", "Potion HUD", .984, .78),
        STATUS("status", "Status", .014, .80),
        WAYPOINT("waypoint", "Waypoint", .50, .023),
        BINDS("binds", "Keybinds", .014, .51),
        ARMOR("armor_hud", "Armor", .48, .975),
        SESSION("session_hud", "Session", .014, .17),
        CPS("cps_hud", "CPS", .014, .34),
        NOTIFICATIONS("notifications", "Notifications", .985, .47);

        public final String moduleId;
        public final String label;
        public final double defaultX, defaultY;
        Widget(String moduleId, String label, double defaultX, double defaultY) {
            this.moduleId = moduleId;
            this.label = label;
            this.defaultX = defaultX;
            this.defaultY = defaultY;
        }
    }
    public static final class Position {
        public double x, y;
        public Position(double x, double y) { this.x = clamp01(x); this.y = clamp01(y); }
    }
    private static final EnumMap<Widget, Position> positions = new EnumMap<>(Widget.class);
    public static Theme theme = Theme.AQUA;
    public static boolean compact = false;
    static { reset(); }
    private HudLayout() {}
    private static double clamp01(double n) { return Math.max(0, Math.min(1, Double.isFinite(n) ? n : 0)); }
    public static void reset() {
        positions.clear();
        for (Widget w : Widget.values()) positions.put(w, new Position(w.defaultX, w.defaultY));
    }
    public static void move(Widget widget, int pixelX, int pixelY, int screenWidth, int screenHeight, int widgetWidth, int widgetHeight) {
        positions.put(widget, new Position((double) pixelX / Math.max(1, screenWidth - widgetWidth),
                (double) pixelY / Math.max(1, screenHeight - widgetHeight)));
    }
    public static void set(Widget widget, double x, double y) { positions.put(widget, new Position(x, y)); }
    public static Position get(Widget widget) { return positions.get(widget); }
    public static int[] rectangle(Widget widget, int screenWidth, int screenHeight, int width, int height) {
        Position p = positions.get(widget);
        return new int[]{(int) Math.round(p.x * Math.max(0, screenWidth - width)),
                (int) Math.round(p.y * Math.max(0, screenHeight - height)), width, height};
    }
    public static void nextTheme() { theme = Theme.values()[(theme.ordinal() + 1) % Theme.values().length]; }
    public static Map<Widget, Position> all() { return Map.copyOf(positions); }
}
