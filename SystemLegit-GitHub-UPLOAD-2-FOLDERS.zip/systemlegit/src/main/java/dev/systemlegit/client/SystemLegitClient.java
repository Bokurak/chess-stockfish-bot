package dev.systemlegit.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.ArrayDeque;
import java.util.Deque;

public final class SystemLegitClient implements ClientModInitializer {
    public static final List<Module> MODULES = new ArrayList<>();
    public static Waypoint waypoint;
    public record Waypoint(String dimension, int x, int y, int z) {}

    private static KeyBinding menuKey;
    private static KeyBinding hudEditorKey;
    private static boolean lastMouseDown;
    private static final Deque<Long> CLICKS = new ArrayDeque<>();
    public static int currentCps;
    private static KeyBinding zoomKey;
    private static KeyBinding waypointKey;
    private static int tickCount;
    private static int lastAutoAttackTick = -100;
    private static boolean zoomApplied;
    private static int savedFov;
    private static boolean appliedNightVision;
    public static LivingEntity recentTarget;
    public static int recentTargetTicks;

    @Override
    public void onInitializeClient() {
        registerModules();
        ConfigStore.load();
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.systemlegit.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.systemlegit"));
        hudEditorKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.systemlegit.hud_editor", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "key.categories.systemlegit"));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.systemlegit.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, "key.categories.systemlegit"));
        waypointKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.systemlegit.waypoint", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_N, "key.categories.systemlegit"));

        ClientTickEvents.END_CLIENT_TICK.register(SystemLegitClient::tick);
        HudRenderCallback.EVENT.register((context, delta) -> HudRenderer.render(context));
    }

    private static void registerModules() {
        add(new Module("aim_assist", "Aim Assist", "Gently rotates toward visible players only while holding attack. Vanilla range.", Module.Category.COMBAT, false, 0.18, 0.05, 0.45, "x"));
        add(new Module("trigger_bot", "TriggerBot", "Attacks a player under your crosshair when the attack cooldown is ready.", Module.Category.COMBAT, false));
        add(new Module("auto_clicker", "AutoClicker", "Repeats attacks while holding left click and looking directly at a player.", Module.Category.COMBAT, false));
        add(new Module("auto_sprint", "Auto Sprint", "Sprints automatically when moving forward and able to sprint.", Module.Category.MOVEMENT, false));
        add(new Module("zoom", "Smooth Zoom", "Hold Z for a narrower field of view. Restores your original FOV.", Module.Category.RENDER, true, 30, 18, 55, " FOV"));
        add(new Module("night_vision", "Night Vision", "Applies a temporary client-side night-vision effect.", Module.Category.RENDER, false));
        add(new Module("crosshair", "Minimal Crosshair", "Small cyan lines in the center of your screen.", Module.Category.RENDER, false));
        add(new Module("arraylist", "Module List", "Shows enabled modules on the right side of the screen.", Module.Category.RENDER, true));
        add(new Module("watermark", "Watermark", "Compact client badge with your current FPS.", Module.Category.HUD, true));
        add(new Module("coordinates", "Coordinates", "Shows your XYZ position and biome-independent dimension ID.", Module.Category.HUD, true));
        add(new Module("keystrokes", "Keystrokes", "Displays live WASD key presses.", Module.Category.HUD, false));
        add(new Module("target_hud", "Target HUD", "Shows current or recently targeted player's health.", Module.Category.HUD, true));
        add(new Module("potions", "Potion HUD", "Lists active potion effects and remaining duration.", Module.Category.HUD, false));
        add(new Module("status", "Status HUD", "Displays health, hunger and ping in a compact panel.", Module.Category.HUD, false));
        add(new Module("binds", "Keybinds HUD", "Shows important client shortcuts in a floating panel.", Module.Category.HUD, false));
        add(new Module("armor_hud", "Armor HUD", "Shows your actual equipped armor items.", Module.Category.HUD, false));
        add(new Module("session_hud", "Session HUD", "Shows playtime since the client started, FPS, and ping.", Module.Category.HUD, true));
        add(new Module("cps_hud", "CPS HUD", "Shows approximate clicks per second; sampled at the 20 TPS client tick rate.", Module.Category.HUD, false));
        add(new Module("notifications", "Notifications", "Shows temporary notices when you toggle client modules.", Module.Category.HUD, true));
        add(new Module("waypoint", "Waypoint HUD", "Shows distance to the waypoint; press N to save your current position.", Module.Category.UTILITY, false));
    }

    private static void add(Module module) { MODULES.add(module); }

    public static Module byId(String id) {
        for (Module m : MODULES) if (m.id.equals(id)) return m;
        throw new IllegalArgumentException("No such module: " + id);
    }

    public static boolean on(String id) { return byId(id).enabled; }

    public static void setEnabled(Module module, boolean enabled) {
        if (module.enabled == enabled) return;
        module.enabled = enabled;
        if (module.id.equals("zoom") && !enabled) restoreFov(MinecraftClient.getInstance());
        if (module.id.equals("night_vision") && !enabled) removeNightVision(MinecraftClient.getInstance());
        ConfigStore.save();
        HudRenderer.notify(module.name, enabled ? "Enabled" : "Disabled");
    }

    private static void sampleClicks(MinecraftClient client) {
        long now = System.currentTimeMillis();
        if (client.player == null || client.currentScreen != null) {
            lastMouseDown = false;
        } else {
            boolean pressed = GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
            if (pressed && !lastMouseDown) CLICKS.addLast(now);
            lastMouseDown = pressed;
        }
        while (!CLICKS.isEmpty() && now - CLICKS.peekFirst() > 1000L) CLICKS.removeFirst();
        currentCps = CLICKS.size();
    }

    private static void tick(MinecraftClient client) {
        tickCount++;
        HudRenderer.sweepNotices();
        sampleClicks(client);
        while (hudEditorKey.wasPressed()) {
            if (client.player != null && client.currentScreen == null) client.setScreen(new HudEditorScreen());
        }
        while (menuKey.wasPressed()) {
            if (client.currentScreen == null) client.setScreen(new LegitScreen());
        }
        while (waypointKey.wasPressed()) saveWaypoint(client);
        updateZoom(client);

        if (client.player == null || client.world == null) {
            recentTarget = null;
            recentTargetTicks = 0;
            appliedNightVision = false;
            return;
        }
        if (recentTargetTicks > 0) recentTargetTicks--;
        else recentTarget = null;
        if (client.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity living && living.isAlive()) {
            recentTarget = living;
            recentTargetTicks = 65;
        }
        updateNightVision(client);
        if (client.currentScreen != null) return;
        if (on("auto_sprint")) autoSprint(client);
        if (on("aim_assist")) aimAssist(client);
        if (on("trigger_bot") || on("auto_clicker")) autoAttack(client);
    }

    private static void autoSprint(MinecraftClient client) {
        if (client.player.input.movementForward > 0.0F && !client.player.isSneaking()
                && !client.player.isUsingItem() && client.player.getHungerManager().getFoodLevel() > 6
                && !client.player.horizontalCollision && !client.player.isSprinting()) {
            client.player.setSprinting(true);
        }
    }

    private static void aimAssist(MinecraftClient client) {
        if (!client.options.attackKey.isPressed() || client.player.isSpectator()) return;
        PlayerEntity nearest = null;
        double closestAngle = 17.0;
        float yaw = client.player.getYaw();
        float pitch = client.player.getPitch();
        Vec3d eye = client.player.getEyePos();
        for (PlayerEntity target : client.world.getPlayers()) {
            if (target == client.player || !target.isAlive() || target.isSpectator() || !client.player.canSee(target)) continue;
            if (eye.distanceTo(target.getEyePos()) > 3.1) continue;
            float[] rotation = lookAt(eye, target.getEyePos());
            double angle = Math.hypot(MathHelper.wrapDegrees(rotation[0] - yaw), rotation[1] - pitch);
            if (angle < closestAngle) { nearest = target; closestAngle = angle; }
        }
        if (nearest == null) return;
        float[] rotation = lookAt(eye, nearest.getEyePos());
        float factor = (float) byId("aim_assist").value;
        client.player.setYaw(yaw + MathHelper.wrapDegrees(rotation[0] - yaw) * factor);
        client.player.setPitch(MathHelper.clamp(pitch + (rotation[1] - pitch) * factor, -90, 90));
    }

    private static float[] lookAt(Vec3d from, Vec3d to) {
        Vec3d d = to.subtract(from);
        double horizontal = Math.sqrt(d.x * d.x + d.z * d.z);
        return new float[]{
                (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0),
                (float) -Math.toDegrees(Math.atan2(d.y, horizontal))
        };
    }

    private static void autoAttack(MinecraftClient client) {
        if (client.interactionManager == null || client.player.isSpectator()) return;
        if (!(client.crosshairTarget instanceof EntityHitResult hit) || !(hit.getEntity() instanceof PlayerEntity target)) return;
        if (target == client.player || !target.isAlive() || target.isSpectator()) return;
        if (client.player.getEyePos().distanceTo(target.getEyePos()) > 3.05 || !client.player.canSee(target)) return;
        // Keep the vanilla combat cooldown and never attack more than once in two ticks.
        if (client.player.getAttackCooldownProgress(0.0F) < 0.98F || tickCount - lastAutoAttackTick < 2) return;
        boolean trigger = on("trigger_bot") && !client.options.attackKey.isPressed();
        boolean auto = on("auto_clicker") && client.options.attackKey.isPressed();
        if (trigger || auto) {
            client.interactionManager.attackEntity(client.player, target);
            client.player.swingHand(Hand.MAIN_HAND);
            lastAutoAttackTick = tickCount;
        }
    }

    private static void updateZoom(MinecraftClient client) {
        boolean wanted = client.player != null && client.currentScreen == null && on("zoom") && zoomKey.isPressed();
        if (wanted) {
            if (!zoomApplied) { savedFov = client.options.getFov().getValue(); zoomApplied = true; }
            client.options.getFov().setValue((int) Math.round(byId("zoom").value));
        } else restoreFov(client);
    }

    private static void restoreFov(MinecraftClient client) {
        if (zoomApplied) { client.options.getFov().setValue(savedFov); zoomApplied = false; }
    }

    private static void updateNightVision(MinecraftClient client) {
        if (!on("night_vision")) { removeNightVision(client); return; }
        if (client.player == null) return;
        StatusEffectInstance current = client.player.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (current == null || (appliedNightVision && current.getDuration() < 60)) {
            client.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 240, 0, true, false, false));
            appliedNightVision = true;
        }
    }

    private static void removeNightVision(MinecraftClient client) {
        if (appliedNightVision && client.player != null) client.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        appliedNightVision = false;
    }

    private static void saveWaypoint(MinecraftClient client) {
        if (client.player == null || client.world == null) return;
        BlockPos p = client.player.getBlockPos();
        waypoint = new Waypoint(client.world.getRegistryKey().getValue().toString(), p.getX(), p.getY(), p.getZ());
        ConfigStore.save();
        client.player.sendMessage(Text.literal("[System Legit] Waypoint saved: " + p.getX() + ", " + p.getY() + ", " + p.getZ()), true);
    }

    public static void clearWaypoint() {
        waypoint = null;
        ConfigStore.save();
    }
}
