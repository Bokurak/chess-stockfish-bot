package dev.systemlegit.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Move widgets with LMB, RMB toggles a widget, T cycles themes, R resets positions. */
public final class HudEditorScreen extends Screen {
    private HudLayout.Widget dragging;
    private int grabX, grabY;
    private HudLayout.Widget hovered;
    private boolean moved;

    public HudEditorScreen() { super(Text.literal("System Legit HUD Editor")); }
    @Override public boolean shouldPause() { return false; }
    @Override public boolean shouldCloseOnEsc() { return true; }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Intentionally semi-transparent; the game remains visible behind the widgets.
        ctx.fill(0, 0, width, height, 0x49080B13);
        HudRenderer.renderEditor(ctx);
        hovered = findWidget(mouseX, mouseY);
        for (HudLayout.Widget widget : HudLayout.Widget.values()) {
            if (!SystemLegitClient.on(widget.moduleId)) continue;
            int[] box = HudRenderer.bounds(widget, width, height, true);
            int c = widget == dragging ? 0xFF74DBD3 : widget == hovered ? 0xFFC0F7F1 : 0x6674DBD3;
            ctx.fill(box[0], box[1], box[0] + box[2], box[1] + 1, c);
            ctx.fill(box[0], box[1] + box[3] - 1, box[0] + box[2], box[1] + box[3], c);
            ctx.fill(box[0], box[1], box[0] + 1, box[1] + box[3], c);
            ctx.fill(box[0] + box[2] - 1, box[1], box[0] + box[2], box[1] + box[3], c);
        }
        ctx.fill(0, 0, width, 31, 0xF0151A27);
        ctx.fill(0, 30, width, 31, HudLayout.theme.accent);
        ctx.drawTextWithShadow(textRenderer, "SYSTEM LEGIT   /   HUD EDITOR", 11, 11, 0xFFFFFFFF);
        String help = "Drag: move  |  RMB: toggle  |  T: theme  |  R: reset  |  ESC: save";
        ctx.drawTextWithShadow(textRenderer, help, Math.max(11, width - textRenderer.getWidth(help) - 11), 11, 0xFFB6C0D4);
        ctx.fill(8, height - 25, 155, height - 7, 0xDC141B29);
        ctx.drawTextWithShadow(textRenderer, "THEME: " + HudLayout.theme.label.toUpperCase(), 17, height - 19, HudLayout.theme.accent);
        if (hovered != null) {
            String tooltip = hovered.label;
            int tw = textRenderer.getWidth(tooltip) + 14;
            ctx.fill(Math.max(0, mouseX + 12), Math.max(32, mouseY + 9), Math.max(0, mouseX + 12) + tw, Math.max(32, mouseY + 9) + 19, 0xEF151926);
            ctx.drawTextWithShadow(textRenderer, tooltip, mouseX + 19, Math.max(32, mouseY + 9) + 5, 0xFFFFFFFF);
        }
        super.render(ctx, mouseX, mouseY, delta);
    }

    private HudLayout.Widget findWidget(int x, int y) {
        if (y < 31) return null;
        HudLayout.Widget[] widgets = HudLayout.Widget.values();
        for (int i = widgets.length - 1; i >= 0; i--) {
            HudLayout.Widget w = widgets[i];
            if (!SystemLegitClient.on(w.moduleId)) continue;
            int[] r = HudRenderer.bounds(w, width, height, true);
            if (x >= r[0] && y >= r[1] && x < r[0] + r[2] && y < r[1] + r[3]) return w;
        }
        return null;
    }
    @Override public boolean mouseClicked(double mx, double my, int button) {
        HudLayout.Widget w = findWidget((int) mx, (int) my);
        if (w != null && button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            int[] r = HudRenderer.bounds(w, width, height, true);
            dragging = w;
            grabX = (int) mx - r[0]; grabY = (int) my - r[1]; moved = false;
            return true;
        }
        if (w != null && button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
            SystemLegitClient.setEnabled(SystemLegitClient.byId(w.moduleId), false);
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }
    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null && button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            int[] r = HudRenderer.bounds(dragging, width, height, true);
            int nx = Math.max(0, Math.min(width - r[2], (int) mx - grabX));
            int ny = Math.max(31, Math.min(height - r[3], (int) my - grabY));
            if (!hasCtrlDown()) { nx = snap(nx, 5); ny = snap(ny, 5); }
            HudLayout.move(dragging, nx, ny, width, height, r[2], r[3]);
            moved = true;
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }
    private int snap(int n, int grid) { return (int) Math.round((double) n / grid) * grid; }
    @Override public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null && button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            dragging = null;
            if (moved) ConfigStore.save();
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }
    @Override public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (key == GLFW.GLFW_KEY_T) { HudLayout.nextTheme(); ConfigStore.save(); return true; }
        if (key == GLFW.GLFW_KEY_R) { HudLayout.reset(); ConfigStore.save(); return true; }
        if (key == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        return super.keyPressed(key, scanCode, modifiers);
    }
    @Override public void close() { ConfigStore.save(); super.close(); }
}
