package dev.systemlegit.client;

public final class Module {
    public enum Category { COMBAT, MOVEMENT, RENDER, HUD, UTILITY }

    public final String id;
    public final String name;
    public final String description;
    public final Category category;
    public final double min;
    public final double max;
    public final String unit;
    public boolean enabled;
    public double value;

    public Module(String id, String name, String description, Category category,
                  boolean enabled) {
        this(id, name, description, category, enabled, 0, 0, 0, "");
    }

    public Module(String id, String name, String description, Category category,
                  boolean enabled, double value, double min, double max, String unit) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.category = category;
        this.enabled = enabled;
        this.value = value;
        this.min = min;
        this.max = max;
        this.unit = unit;
    }

    public boolean hasSlider() { return max > min; }

    public void setValue(double next) {
        if (hasSlider()) {
            value = Math.round(Math.max(min, Math.min(max, next)) * 100.0) / 100.0;
        }
    }

    public String formattedValue() {
        return (Math.floor(value) == value ? Integer.toString((int) value) : String.format(java.util.Locale.US, "%.2f", value)) + unit;
    }
}
