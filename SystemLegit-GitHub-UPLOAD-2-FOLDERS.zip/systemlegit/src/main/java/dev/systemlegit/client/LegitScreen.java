package dev.systemlegit.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public final class LegitScreen extends Screen {
    private static final int BG = 0xF0111420;
    private static final int SIDEBAR = 0xFF171C2B;
    private static final int SURFACE = 0xFF202638;
    private static final int HOVER = 0xFF2D364C;
    private static final int ACCENT = HudRenderer.ACCENT;
    private static final int TEXT = HudRenderer.WHITE;
    private static final int SUB = HudRenderer.MUTED;

    private Module.Category category = Module.Category.COMBAT;
    private Module selected;
    private int scroll;
    private boolean sliding;
    private int px, py, pw, ph, modulesX, modulesW, detailX, detailW;

    public LegitScreen() {
        super(Text.literal("SYSTEM LEGIT"));
        selected = filtered().get(0);
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        px = (width - Math.min(650, width - 20)) / 2;
        py = (height - Math.min(386, height - 20)) / 2;
        pw = Math.min(650, width - 20);
        ph = Math.min(386, height - 20);
        int sidebarW = Math.max(92, Math.min(128, pw / 5));
        modulesX = px + sidebarW + 14;
        modulesW = Math.min(212, (pw - sidebarW - 25) * 54 / 100);
        detailX = modulesX + modulesW + 12;
        detailW = Math.max(50, px + pw - detailX - 13);

        // The screen dims the world but does not cover it in full-screen blur.
        ctx.fill(0, 0, width, height, 0x9C05070C);
        ctx.fill(px + 6, py + 7, px + pw + 6, py + ph + 7, 0x70000000);
        ctx.fill(px, py, px + pw, py + ph, BG);
        ctx.fill(px, py, px + Math.max(92, Math.min(128, pw / 5)), py + ph, SIDEBAR);
        ctx.fill(px, py, px + pw, py + 2, ACCENT);

        label(ctx, "S", px + 17, py + 17, ACCENT);
        label(ctx, "SYSTEM", px + 30, py + 18, TEXT);
        label(ctx, "LEGIT", px + 30, py + 30, SUB);
        ctx.fill(px + 13, py + 54, px + sidebarW - 12, py + 55, 0xFF30384B);
        label(ctx, "CATEGORIES", px + 14, py + 65, SUB);

        int catY = py + 88;
        for (Module.Category entry : Module.Category.values()) {
            int i = entry.ordinal();
            int yy = catY + i * 34;
            boolean active = entry == category;
            if (active) {
                ctx.fill(px + 8, yy - 3, px + sidebarW - 7, yy + 23, SURFACE);
                ctx.fill(px + 8, yy - 3, px + 11, yy + 23, ACCENT);
            } else if (inside(mouseX, mouseY, px + 8, yy - 3, sidebarW - 15, 26)) {
                ctx.fill(px + 8, yy - 3, px + sidebarW - 7, yy + 23, HOVER);
            }
            label(ctx, entry.name(), px + 18, yy + 5, active ? TEXT : SUB);
        }
        label(ctx, "v0.2 HUD", px + 15, py + ph - 19, SUB);

        label(ctx, category.name(), modulesX, py + 17, TEXT);
        label(ctx, "Select a module to configure", modulesX, py + 32, SUB);
        int listTop = py + 55;
        int visible = visibleCount();
        List<Module> list = filtered();
        scroll = Math.max(0, Math.min(scroll, Math.max(0, list.size() - visible)));
        for (int row = 0; row < visible && scroll + row < list.size(); row++) {
            Module m = list.get(scroll + row);
            int yy = listTop + row * 47;
            boolean hovered = inside(mouseX, mouseY, modulesX, yy, modulesW, 42);
            int color = selected == m ? 0xFF29364C : hovered ? HOVER : SURFACE;
            ctx.fill(modulesX, yy, modulesX + modulesW, yy + 42, color);
            if (selected == m) ctx.fill(modulesX, yy, modulesX + 3, yy + 42, ACCENT);
            label(ctx, clipped(m.name, modulesW - 66), modulesX + 11, yy + 9, TEXT);
            label(ctx, m.enabled ? "ACTIVE" : "OFF", modulesX + 11, yy + 24, m.enabled ? ACCENT : SUB);
            toggle(ctx, modulesX + modulesW - 40, yy + 13, m.enabled);
        }
        if (list.size() > visible) {
            label(ctx, (scroll + 1) + "-" + Math.min(list.size(), scroll + visible) + " / " + list.size(),
                    modulesX, py + ph - 27, SUB);
        }
        ctx.fill(detailX - 6, py + 15, detailX - 5, py + ph - 40, 0xFF30384B);

        if (selected != null) {
            label(ctx, clipped(selected.name, detailW - 2), detailX + 4, py + 18, TEXT);
            label(ctx, "MODULE SETTINGS", detailX + 4, py + 36, SUB);
            int yy = py + 61;
            for (String line : wrapped(selected.description, Math.max(45, detailW - 8))) {
                label(ctx, line, detailX + 4, yy, SUB);
                yy += 13;
            }
            int stateY = py + 145;
            label(ctx, "ENABLED", detailX + 4, stateY, TEXT);
            toggle(ctx, detailX + detailW - 36, stateY - 6, selected.enabled);
            ctx.fill(detailX + 4, stateY + 21, detailX + detailW - 3, stateY + 22, 0xFF333A4D);
            if (selected.hasSlider()) {
                label(ctx, "STRENGTH / LEVEL", detailX + 4, stateY + 34, SUB);
                label(ctx, selected.formattedValue(), detailX + 4, stateY + 51, TEXT);
                int sx = sliderX();
                int sy = sliderY();
                int sw = sliderW();
                ctx.fill(sx, sy, sx + sw, sy + 4, 0xFF414A60);
                int progress = (int) Math.round(((selected.value - selected.min) / (selected.max - selected.min)) * sw);
                ctx.fill(sx, sy, sx + progress, sy + 4, ACCENT);
                ctx.fill(sx + progress - 2, sy - 3, sx + progress + 3, sy + 7, TEXT);
            } else {
                label(ctx, "No additional settings", detailX + 4, stateY + 38, SUB);
            }
            if (selected.id.equals("waypoint")) {
                ctx.fill(detailX + 4, py + ph - 80, detailX + detailW - 5, py + ph - 56, HOVER);
                label(ctx, "CLEAR WAYPOINT", detailX + 9, py + ph - 72, TEXT);
            }
        }

        ctx.fill(modulesX, py + ph - 38, px + pw - 15, py + ph - 37, 0xFF30384B);
        ctx.fill(modulesX, py + ph - 33, modulesX + 117, py + ph - 9, 0xFF315D65);
        label(ctx, "EDIT HUD  [H]", modulesX + 10, py + ph - 25, TEXT);
        ctx.fill(modulesX + 124, py + ph - 33, modulesX + 244, py + ph - 9, 0xFF29364C);
        label(ctx, "THEME: " + HudLayout.theme.label, modulesX + 132, py + ph - 25, ACCENT);
        label(ctx, "ESC", px + pw - 34, py + 18, SUB);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private int visibleCount() { return Math.max(1, (ph - 103) / 47); }
    private int sliderX() { return detailX + 5; }
    private int sliderY() { return py + 244; }
    private int sliderW() { return Math.max(20, detailW - 19); }

    private List<Module> filtered() {
        List<Module> list = new ArrayList<>();
        for (Module m : SystemLegitClient.MODULES) if (m.category == category) list.add(m);
        return list;
    }

    private void selectCategory(Module.Category next) {
        category = next;
        scroll = 0;
        List<Module> modules = filtered();
        selected = modules.isEmpty() ? null : modules.get(0);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT) return super.mouseClicked(mx, my, button);
        int x = (int) mx, y = (int) my;
        int sidebarW = Math.max(92, Math.min(128, pw / 5));
        if (inside(x, y, px + 7, py + 85, sidebarW - 13, 5 * 34)) {
            int index = (y - (py + 85)) / 34;
            if (index < Module.Category.values().length) selectCategory(Module.Category.values()[index]);
            return true;
        }
        if (inside(x, y, px + pw - 40, py + 10, 34, 20)) { close(); return true; }
        if (inside(x, y, modulesX, py + ph - 33, 117, 24)) {
            if (client != null && client.player != null) client.setScreen(new HudEditorScreen());
            return true;
        }
        if (inside(x, y, modulesX + 124, py + ph - 33, 120, 24)) {
            HudLayout.nextTheme(); ConfigStore.save(); return true;
        }
        if (inside(x, y, modulesX, py + 55, modulesW, visibleCount() * 47)) {
            int index = scroll + (y - (py + 55)) / 47;
            List<Module> modules = filtered();
            if (index < modules.size()) {
                selected = modules.get(index);
                if (x >= modulesX + modulesW - 47) SystemLegitClient.setEnabled(selected, !selected.enabled);
                return true;
            }
        }
        if (selected != null) {
            if (inside(x, y, detailX, py + 135, detailW, 28)) {
                SystemLegitClient.setEnabled(selected, !selected.enabled);
                return true;
            }
            if (selected.hasSlider() && inside(x, y, sliderX() - 4, sliderY() - 7, sliderW() + 9, 17)) {
                sliding = true;
                applySlider(mx);
                return true;
            }
            if (selected.id.equals("waypoint") && inside(x, y, detailX + 4, py + ph - 80, detailW - 9, 24)) {
                SystemLegitClient.clearWaypoint();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (sliding && button == GLFW.GLFW_MOUSE_BUTTON_LEFT) { applySlider(mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (sliding) { sliding = false; ConfigStore.save(); return true; }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        if (inside((int) mx, (int) my, modulesX, py + 55, modulesW, ph - 95)) {
            scroll -= (int) Math.signum(vertical);
            int size = filtered().size();
            scroll = Math.max(0, Math.min(scroll, Math.max(0, size - visibleCount())));
            return true;
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private void applySlider(double mx) {
        if (selected == null || !selected.hasSlider()) return;
        double percent = Math.max(0.0, Math.min(1.0, (mx - sliderX()) / sliderW()));
        selected.setValue(selected.min + percent * (selected.max - selected.min));
    }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && my >= y && mx < x + w && my < y + h;
    }

    private void label(DrawContext c, String text, int x, int y, int color) {
        c.drawTextWithShadow(textRenderer, text, x, y, color);
    }

    private String clipped(String value, int width) {
        return textRenderer.trimToWidth(value, Math.max(12, width));
    }

    private List<String> wrapped(String source, int width) {
        List<String> lines = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        for (String word : source.split(" ")) {
            String next = sb.isEmpty() ? word : sb + " " + word;
            if (textRenderer.getWidth(next) > width && !sb.isEmpty()) {
                lines.add(sb.toString());
                sb.setLength(0);
            }
            if (!sb.isEmpty()) sb.append(' ');
            sb.append(word);
        }
        if (!sb.isEmpty()) lines.add(sb.toString());
        if (lines.size() > 5) return lines.subList(0, 5);
        return lines;
    }

    private static void toggle(DrawContext ctx, int x, int y, boolean enabled) {
        ctx.fill(x, y, x + 29, y + 16, enabled ? 0xFF357E7B : 0xFF444A5E);
        ctx.fill(enabled ? x + 16 : x + 3, y + 3, enabled ? x + 26 : x + 13, y + 13, enabled ? 0xFFF6FFFF : 0xFFBBC2D3);
    }
}
