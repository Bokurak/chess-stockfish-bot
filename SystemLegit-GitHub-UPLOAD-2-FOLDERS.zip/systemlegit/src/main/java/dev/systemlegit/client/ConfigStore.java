package dev.systemlegit.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigStore {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("systemlegit.json");

    private ConfigStore() {}

    public static void load() {
        if (!Files.isRegularFile(PATH)) return;
        try (Reader reader = Files.newBufferedReader(PATH, StandardCharsets.UTF_8)) {
            JsonObject obj = JsonParser.parseReader(reader).getAsJsonObject();
            if (obj.has("modules") && obj.get("modules").isJsonObject()) {
                JsonObject modules = obj.getAsJsonObject("modules");
                for (Module m : SystemLegitClient.MODULES) {
                    JsonElement entry = modules.get(m.id);
                    if (entry == null || !entry.isJsonObject()) continue;
                    JsonObject state = entry.getAsJsonObject();
                    if (state.has("enabled")) m.enabled = state.get("enabled").getAsBoolean();
                    if (state.has("value") && m.hasSlider()) m.setValue(state.get("value").getAsDouble());
                }
            }
            if (obj.has("hud") && obj.get("hud").isJsonObject()) {
                JsonObject hud = obj.getAsJsonObject("hud");
                if (hud.has("theme")) {
                    try { HudLayout.theme = HudLayout.Theme.valueOf(hud.get("theme").getAsString()); }
                    catch (IllegalArgumentException ignored) { }
                }
                if (hud.has("positions") && hud.get("positions").isJsonObject()) {
                    JsonObject pos = hud.getAsJsonObject("positions");
                    for (HudLayout.Widget w : HudLayout.Widget.values()) {
                        if (!pos.has(w.name()) || !pos.get(w.name()).isJsonObject()) continue;
                        JsonObject v = pos.getAsJsonObject(w.name());
                        if (v.has("x") && v.has("y")) HudLayout.set(w, v.get("x").getAsDouble(), v.get("y").getAsDouble());
                    }
                }
            }
            if (obj.has("waypoint") && obj.get("waypoint").isJsonObject()) {
                JsonObject wp = obj.getAsJsonObject("waypoint");
                String dimension = wp.get("dimension").getAsString();
                int x = wp.get("x").getAsInt();
                int y = wp.get("y").getAsInt();
                int z = wp.get("z").getAsInt();
                SystemLegitClient.waypoint = new SystemLegitClient.Waypoint(dimension, x, y, z);
            }
        } catch (Exception e) {
            System.err.println("[System Legit] Config load failed: " + e.getMessage());
        }
    }

    public static void save() {
        JsonObject root = new JsonObject();
        root.addProperty("schema", 2);
        JsonObject modules = new JsonObject();
        for (Module m : SystemLegitClient.MODULES) {
            JsonObject state = new JsonObject();
            state.addProperty("enabled", m.enabled);
            if (m.hasSlider()) state.addProperty("value", m.value);
            modules.add(m.id, state);
        }
        root.add("modules", modules);
        JsonObject hud = new JsonObject();
        hud.addProperty("theme", HudLayout.theme.name());
        JsonObject pos = new JsonObject();
        for (HudLayout.Widget w : HudLayout.Widget.values()) {
            HudLayout.Position v = HudLayout.get(w);
            JsonObject xy = new JsonObject();
            xy.addProperty("x", v.x);
            xy.addProperty("y", v.y);
            pos.add(w.name(), xy);
        }
        hud.add("positions", pos);
        root.add("hud", hud);
        if (SystemLegitClient.waypoint != null) {
            var wp = SystemLegitClient.waypoint;
            JsonObject w = new JsonObject();
            w.addProperty("dimension", wp.dimension());
            w.addProperty("x", wp.x());
            w.addProperty("y", wp.y());
            w.addProperty("z", wp.z());
            root.add("waypoint", w);
        }
        try {
            Files.createDirectories(PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(PATH, StandardCharsets.UTF_8)) {
                GSON.toJson(root, writer);
            }
        } catch (Exception e) {
            System.err.println("[System Legit] Config save failed: " + e.getMessage());
        }
    }
}
