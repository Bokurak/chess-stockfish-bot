# System Legit — Fabric 1.21.1 (source project)

A clean-room, client-side Minecraft Java Edition mod **inspired by the feature layout** of systemdlc.com. No code or assets from SystemDLC are included. This is a **source-code release** (not a compiled `.jar`).

## Game & build requirements

- Minecraft Java Edition **1.21.1**
- **Java Development Kit 21** (JDK, not only JRE)
- Network access for downloading Gradle, Fabric Loom, Minecraft libraries and other dependencies; **BUILD_JAR.bat** downloads Gradle automatically
- Fabric Loader compatible with Minecraft 1.21.1 and Fabric API `0.116.8+1.21.1`

Version pins are in `gradle.properties`. The build uses Yarn mappings `1.21.1+build.3` and Fabric Loom `1.11.8`.

## Build (Windows): one click

1. Install **JDK 21**: https://adoptium.net/temurin/releases/?version=21 .
2. Double-click **`BUILD_JAR.bat`**.
3. The script automatically downloads official Gradle **8.14.3** when needed and runs `gradle clean build`.
4. If the real Gradle build succeeds, the installable mod is copied to **`SystemLegit-1.21.1.jar`** next to the script. It may optionally be copied to Minecraft's mods folder.

A network connection is required. No executable `.jar` is prebuilt inside this ZIP.
The Minecraft/Fabric compilation was **not verified** in the authoring environment because Gradle and Maven libraries are inaccessible there. Source-level `javac` checks against temporary API stand-ins pass after fixing a `WHITE` symbol error in the GUI. A Java-only stub compile is not a replacement for an actual Loom build or runtime test.

## Install

1. Install Fabric Loader for **Minecraft 1.21.1** through https://fabricmc.net/use/installer/ .
2. Download the compatible Fabric API from https://modrinth.com/mod/fabric-api .
3. Put the generated JAR **and** Fabric API JAR into `%APPDATA%\.minecraft\mods`.
4. Choose the Fabric 1.21.1 profile in the Minecraft Launcher.

## Controls

| Key | Action |
|---|---|
| `Right Shift` | Open/close the built-in ClickGUI |
| `Z` (hold) | Zoom (if Zoom module is enabled) |
| `N` | Save your position as waypoint (same-world coordinates) |
| `Esc` | Close ClickGUI |
| `Mouse wheel` | Scroll module list |
| Left click toggle switch | Enable/disable a module |
| Left click module name | Show module description and settings |
| Drag slider | Change Aim Assist strength or Zoom FOV |

All bindings can be changed in Minecraft's Controls -> Key Binds -> System Legit.

## Modules

### Combat
- **Aim Assist** — smooth head rotation toward **visible players within 3.1 blocks** while left mouse button is pressed. The slider changes interpolation strength. Does not spoof packets or change server hit range.
- **TriggerBot** — attacks a player directly under the crosshair when the game cooldown is ready and left mouse is not held.
- **AutoClicker** — performs game-timed attacks while left mouse is held on a player. Only when crosshair actually targets a player.

### Movement
- **Auto Sprint** — starts sprinting automatically while the game allows sprinting.

### Render
- **Smooth Zoom** — hold `Z`; restores your previous FOV when released.
- **Night Vision** — applies a client-side temporary night vision effect; **may conflict with legitimate server-granted night vision**. Avoid using simultaneously with a real night vision potion. It is not a shader-based true fullbright.
- **Minimal Crosshair** — adds a cyan reticle.
- **Module List** — lists enabled modules.

### HUD
- **Watermark** — client badge and FPS.
- **Coordinates** — position.
- **Keystrokes** — live WASD.
- **Target HUD** — health of a targeted player.
- **Potion HUD** — active status effects and timers.
- **Status HUD** — health and hunger.

### Utility
- **Waypoint HUD** — shows waypoint coordinates, approximate horizontal distance and direction when the dimension matches. `N` saves a new waypoint. The GUI contains a waypoint clear button.

## Settings persistence

Module switches, sliders and a waypoint are saved locally at:

`%APPDATA%\.minecraft\config\systemlegit.json`

One global local config; there is **no web sync, account system, client injector, loader, subscription system or anti-cheat bypass**.

## Project layout

- `SystemLegitClient.java` — registration, keybinds, tick handlers and gameplay behavior.
- `Module.java` — typed module definitions, categories, slider values.
- `ConfigStore.java` — load/save JSON using bundled Gson.
- `HudRenderer.java` — HUD widgets in `DrawContext`.
- `LegitScreen.java` — in-game configurable ClickGUI.
- `src/main/resources/fabric.mod.json` — Fabric metadata.

## Technical limitations and fair-play note

This is **not** a copy of the proprietary SystemDLC client. It deliberately uses Fabric APIs rather than injection. It does not guarantee evasion of anti-cheat systems, bypass server restrictions, expand legal reach or avoid server-side checks. Some server rules prohibit automated combat even if the game uses normal attack mechanics. Use it only on servers where you have permission.

**Validation status:** Resources have been parsed and package consistency checked. Full `gradle build`, Minecraft runtime testing and any anti-cheat compatibility testing are **not verified**. External dependencies cannot be fetched in this environment. If a build fails, include the first compiler error and the version numbers from `gradle.properties`.

---

## NEW in v0.2 — HUD system (source update)

This build extends the original v0.1 source with a standalone movable HUD system and four selectable visual themes. It is an independent implementation; it **does not include** code or assets from Meteor, LiquidBounce, Rise, or SystemDLC.

### Added / enhanced widgets

| Widget | Implementation |
| --- | --- |
| Target HUD | Target name, 2D face from Minecraft skin textures, smoothed health bar, absorption indicator, and measured distance. The player under the crosshair remains visible for 65 client ticks. |
| Watermark | Compact two-line badge with Minecraft version and FPS. |
| Active Modules | Auto-width list of enabled combat, movement and render modules, longest first. |
| Coordinates | XYZ and dimension; persists at screen-relative layout position. |
| Potion HUD | Up to five active effects with amplifiers and remaining time. |
| Player Status | Health, food, armor and ping with health bar. |
| Key Strokes | WASD, LMB and RMB keypress indicators. |
| Keybinds | Fixed shortcut reference list. |
| Armor | Live equipped helmet, chestplate, leggings and boots item icons. |
| Session Info | Client run duration (not server uptime), FPS, ping. |
| CPS | **Approximate** mouse click rate sampled once per Minecraft client tick (20 Hz); rapid presses between ticks will be missed. |
| Notifications | Module toggle messages that expire after 3.8 seconds. |
| Waypoint | Saved waypoint XYZ and estimated horizontal distance in the same dimension. |

**Important:** the live Target HUD appears only when a player has recently been targeted. In the editor it uses a preview of the local player, not a fabricated online opponent. Color themes: Aqua, Violet, Rose and Amber. Existing module state continues to be loaded from `config/systemlegit.json`; a new `hud` JSON object stores the theme and normalized widget positions.

### HUD Editor controls

- `H` while playing — open the HUD Editor.
- `Right Shift` while playing — open ClickGUI, then click **EDIT HUD [H]**.
- Drag visible HUD panels using the left mouse button to move them. Positions are saved on release.
- By default panels snap to a 5-pixel grid. Hold `Ctrl` while dragging for fine positioning.
- Right-click a panel in the editor to disable its HUD module (re-enable in ClickGUI > HUD).
- Press `T` in the editor to cycle themes, `R` to reset all widget positions, `Esc` to save and close.
- Click **THEME** in ClickGUI to cycle themes without entering the editor.

### Build and test status

The new Java classes were written for the same Fabric 1.21.1 / Yarn configuration as v0.1, using `DrawContext`, `HudRenderCallback`, `PlayerListEntry` and vanilla client APIs. Only source-level and local Java-only compilation checks were available in the authoring environment. **The entire mod has not been built against Fabric dependencies, and Minecraft runtime behavior has not been verified.** Build with `BUILD_JAR.bat` on a Windows system with JDK 21 and Internet access to Maven repositories. If you encounter a compile error, share the first error and the affected line so it can be repaired precisely.
