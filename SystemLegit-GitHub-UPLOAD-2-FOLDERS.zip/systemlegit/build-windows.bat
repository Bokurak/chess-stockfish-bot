@echo off
setlocal
where java >nul 2>&1 || (echo JDK 21 is required.& exit /b 1)
where gradle >nul 2>&1 || (echo Gradle not installed. Install Gradle and JDK 21. & exit /b 1)
echo Building SystemLegit v0.2...
call gradle clean build
if errorlevel 1 (echo Build failed. See compiler error above. & exit /b 1)
echo Done. Open build\libs and use the JAR without -sources in the name.
endlocal
